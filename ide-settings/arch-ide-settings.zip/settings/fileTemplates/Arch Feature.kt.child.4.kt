#set($PACKAGE_SUFFIX = "ui")
#parse("ArchPackage.kt")

interface ${NAME}Intent {
    fun onBackClicked()
}