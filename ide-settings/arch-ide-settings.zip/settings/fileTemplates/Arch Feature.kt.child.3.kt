#set($PACKAGE_SUFFIX = "ui.mvi")
#parse("ArchPackage.kt")
#parse("ArchImport.kt")

import androidx.compose.runtime.Immutable
import com.example.core.ui.mvi.Reducer


@Immutable
data class ${NAME}State(
    val isLoading: Boolean = false,
): Reducer.ViewState