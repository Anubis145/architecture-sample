#set($PACKAGE_SUFFIX = "ui.mvi")
#parse("ArchPackage.kt")
#parse("ArchImport.kt")

import com.example.core.ui.mvi.Reducer


sealed interface ${NAME}Event: Reducer.ViewEvent {
    data object OnBackClicked: ${NAME}Event
}