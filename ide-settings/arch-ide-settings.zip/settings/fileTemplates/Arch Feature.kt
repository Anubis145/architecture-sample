#set($PACKAGE_SUFFIX = "ui")
#parse("ArchImports.kt")
#parse("ArchPackage.kt")

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ramcosta.composedestinations.annotation.Destination
import com.ramcosta.composedestinations.navigation.DependenciesContainerBuilder
import com.ramcosta.composedestinations.navigation.DestinationsNavigator
import com.ramcosta.composedestinations.navigation.dependency
import ${IMPORT_PREFIX}.navigation.${NAME}ExternalNavigator
import ${IMPORT_PREFIX}.navigation.${NAME}NavGraph
import ${IMPORT_PREFIX}.ui.mvi.${NAME}State


@Destination<${NAME}NavGraph>(start = true)
@Composable
fun ${NAME}Screen(
    viewModel: ${NAME}ViewModel = hiltViewModel(),
    destinationsNavigator: DestinationsNavigator,
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    ${NAME}ScreenContent(
        state = state,
        intentListener = viewModel
    )
}

@Composable
fun ${NAME}ScreenContent(
    state: ${NAME}State,
    intentListener: ${NAME}Intent,
) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "${NAME} Screen"
        )
    }
}

@Composable
@Preview(showBackground = true)
fun ${NAME}ScreenPreview() {
    val intentListener = object : ${NAME}Intent {}

    ${NAME}ScreenContent(
        intentListener = intentListener,
        state = ${NAME}State(
            isLoading = false
        )
    )
}
