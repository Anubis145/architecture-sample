#set($PACKAGE_SUFFIX = "ui.mvi")
#parse("ArchPackage.kt")

import com.example.core.ui.mvi.Reducer
import javax.inject.Inject

class ${NAME}Reducer @Inject constructor() : Reducer<${NAME}State, ${NAME}Event, ${NAME}Effect> {
    override fun reduce(
        previousState: ${NAME}State,
        event: ${NAME}Event
    ): Pair<${NAME}State, ${NAME}Effect?> {
        return when (event) {
            is ${NAME}Event.OnBackClicked -> previousState to ${NAME}Effect.NavigateBack
        }
    }
}