#set($PACKAGE_SUFFIX = "ui")
#parse("ArchPackage.kt")
#parse("ArchImport.kt")

import com.example.core.ui.mvi.BaseViewModel
${IMPORT_PREFIX}.ui.mvi.${NAME}Effect
${IMPORT_PREFIX}.ui.mvi.${NAME}Event
${IMPORT_PREFIX}.ui.mvi.${NAME}Reducer
${IMPORT_PREFIX}.ui.mvi.${NAME}State
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject


@HiltViewModel
class ${NAME}ViewModel @Inject constructor(
    reducer: ${NAME}Reducer,
) : BaseViewModel<${NAME}State, ${NAME}Event, ${NAME}Effect>(
    initialState = ${NAME}State(isLoading = true),
    reducer = reducer,
), ${NAME}Intent {
    
    init {
    
    }
}