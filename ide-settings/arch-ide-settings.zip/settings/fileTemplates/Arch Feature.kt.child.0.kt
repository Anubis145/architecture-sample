#set($PACKAGE_SUFFIX = "ui.mvi")
#parse("ArchPackage.kt")
#parse("ArchImport.kt")

import com.example.core.ui.mvi.Reducer


sealed interface ${NAME}Effect: Reducer.ViewEffect {
    data object NavigateBack: ${NAME}Effect
}