#set($PACKAGE_SUFFIX = "navigation")
#parse("ArchPackage.kt")

import com.ramcosta.composedestinations.annotation.ExternalModuleGraph
import com.ramcosta.composedestinations.annotation.NavGraph


@NavGraph<ExternalModuleGraph>
annotation class ${NAME}Graph