#if (${PACKAGE_NAME} != "")
    #set($OUT_PACKAGE = $PACKAGE_NAME)
#else
    #set($OUT_PACKAGE = "")
#end

#if ($OUT_PACKAGE != "" && $PACKAGE_SUFFIX && $PACKAGE_SUFFIX != "")
package ${OUT_PACKAGE}.${PACKAGE_SUFFIX}
#elseif ($OUT_PACKAGE != "")
package ${OUT_PACKAGE}
#elseif ($PACKAGE_SUFFIX && $PACKAGE_SUFFIX != "")
package $PACKAGE_SUFFIX
#end